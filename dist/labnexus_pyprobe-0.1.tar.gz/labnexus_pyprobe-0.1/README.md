# pyProbe
Want to automate your data syncronisation workload with your [LabNexus](https://github.com/CdeBeer7th/labnexus_server) server?

Simply download the ipynb or Python prober, specify your data directory and Labnexus server instance, and run it.

pyProbe will automatically upload your data to the server so you don't have to!

# Setup Example:

python -u file_prober.py ../../local_scripts/testfiles/ 'http://127.0.0.1:8000'
